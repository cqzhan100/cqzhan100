package com.itheima.orm;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import com.itheima.utils.MappingUtils;

//专门来管理配置,生成对应mappingMap
public class Configuration {
	
	Map<String, Mapping> mappingMap = new HashMap<String, Mapping>();
	
	//加载配置
	public void config(){
		try {
			//1.创建SaxReader对象
			SAXReader saxReader = new SAXReader();
			//2.读取配置文件
			Document document = saxReader.read("src/configuration.xml");
			//3.获得根标签对象
			Element rootElement = document.getRootElement();
			//4.获得子标签对象
			List<Element> elements = rootElement.elements();
			for (Element element : elements) {
				String resourceValue = element.attributeValue("resource");
				Mapping mapping = MappingUtils.parseXml("src/"+resourceValue);
				
				mappingMap.put(mapping.getClassName(), mapping);
			
			}
			
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	 
	public Session openSession(){
		Session session = new  Session();
		session.setMappingMap(mappingMap);
		return session;
	}

}
