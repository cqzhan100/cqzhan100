package com.itheima.orm;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.commons.dbutils.QueryRunner;
import com.itheima.utils.C3P0Utils;

//操作数据库的会话(不改java源码,解耦),不管mapping.mapping配置专门由Configuration.java类来管理
public class Session {
	
	//Mapping mapping = MappingUtils.parseXml("src/com/itheima/bean/Stu.xml");
	
	//key就是类名(全限定名),值就是类对应的Mapping对象
	Map<String, Mapping> mappingMap;
	
	public void setMappingMap(Map<String, Mapping> mappingMap) {
		this.mappingMap = mappingMap;
	}
	

	//只让当前包里面的类创建
	protected Session(){
		
	}


	public void save(Object object) throws Exception{
		//类名: 类名是Studnet-->Student.xml
		
		
		//得到字节码
		Class clazz =  object.getClass();
		//得到类的全限定名
		String className = clazz.getName();
		Mapping mapping = mappingMap.get(className);
		
	
		QueryRunner queryRunner = new QueryRunner(C3P0Utils.getDataSource());
		String sql ="insert into t_user(username,age) values(?,?)";
		
		//拼接SQl语句
		StringBuilder sqlSb = new StringBuilder("insert into "+mapping.getTableName()+"(");
		//拼接?
		StringBuilder paramSb = new StringBuilder();
		//拼接列名
		Map<String, String> properties = mapping.getProperties();
		Set<Entry<String, String>> entrySet = properties.entrySet();
		//传入的值
		Object[] params = new Object[entrySet.size()];
		
		int index = 0;
		//遍历map
		for (Entry<String, String> entry : entrySet) {
			//拿到的是列名
			String columnName = entry.getValue();
			//拿到JavaBean属性
			String propertyName = entry.getKey();
			//反射得到对应的Filed
			Field field = clazz.getDeclaredField(propertyName);
			field.setAccessible(true);
			Object value = field.get(object);
			
			params[index] = value;
			
			//一个列名对应一个?
			sqlSb.append(columnName);
			paramSb.append("?");
			//entrySet的size就是列名的个数
			if(index == entrySet.size()-1){
				break;
			}
			
			sqlSb.append(",");
			paramSb.append(",");
			
			index ++;
		}
		
		
		sqlSb.append(") values(");
		
		//拼接问号
		sqlSb.append(paramSb.toString());
		
		sqlSb.append(")");
		
		//System.out.println(sqlSb.toString());
		
		
		queryRunner.update(sqlSb.toString(),params);
		
	}
}
