package com.itheima.orm;

import java.util.HashMap;
import java.util.Map;

public class Mapping {
	//类名和表名
	private String className;
	private String tableName;
	
	//主键id
	private String idProperty;
	private String idColumn;
	
	//其它的属性(key是JavaBean属性,值是数据库里面的列名)
	private Map<String, String> properties = new HashMap<String, String>();

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getIdProperty() {
		return idProperty;
	}

	public void setIdProperty(String idProperty) {
		this.idProperty = idProperty;
	}

	public String getIdColumn() {
		return idColumn;
	}

	public void setIdColumn(String idColumn) {
		this.idColumn = idColumn;
	}

	public Map<String, String> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, String> properties) {
		this.properties = properties;
	}
}
