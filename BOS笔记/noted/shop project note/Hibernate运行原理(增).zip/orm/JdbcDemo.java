package com.itheima.jdbc;

import java.lang.reflect.Field;
import java.sql.SQLException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.jws.soap.SOAPBinding.Use;

import org.apache.commons.dbutils.QueryRunner;
import org.junit.Test;

import com.itheima.bean.Product;
import com.itheima.bean.Student;
import com.itheima.bean.User;
import com.itheima.orm.Configuration;
import com.itheima.orm.Mapping;
import com.itheima.orm.Session;
import com.itheima.utils.C3P0Utils;
import com.itheima.utils.MappingUtils;

public class JdbcDemo {
	
	@Test
	public void fun01() throws Exception{
	/*	User user = new User();
		user.setUsername("李四");
		user.setAge(19);*/
		
		//save(user);
		
/*		Product product = new Product();
		product.setPname("iPhone");
		product.setPdesc("可以被核桃砸...");
		save(product);*/
		
		Student student = new Student();
		student.setName("李四");
		student.setSex("女");
		student.setAge(18);
		student.setGrade(90);
		
		//1.创建Configuration
		Configuration configuration = new Configuration();
		//2.加载配置
		configuration.config();
		//3.创建session
		Session session = configuration.openSession();
		
		session.save(student);
	}
	
	
/*	//保存对象
	*//**
	 * 相同:步骤一样
	 * 不同点: 1.sql语句不一样(表名,列名(?))--->来自数据库 表
	 * 		 2.参数的值不一样--->来在类(对象)
	 *//*
	
	Mapping mapping = MappingUtils.parseXml("src/com/itheima/bean/Student.xml");
	
	public void save(Object object) throws Exception{
			//得到字节码
			Class clazz =  object.getClass();
		
			QueryRunner queryRunner = new QueryRunner(C3P0Utils.getDataSource());
			String sql ="insert into t_user(username,age) values(?,?)";
			
			//拼接SQl语句
			StringBuilder sqlSb = new StringBuilder("insert into "+mapping.getTableName()+"(");
			//拼接?
			StringBuilder paramSb = new StringBuilder();
			//拼接列名
			Map<String, String> properties = mapping.getProperties();
			Set<Entry<String, String>> entrySet = properties.entrySet();
			//传入的值
			Object[] params = new Object[entrySet.size()];
			
			int index = 0;
			//遍历map
			for (Entry<String, String> entry : entrySet) {
				//拿到的是列名
				String columnName = entry.getValue();
				//拿到JavaBean属性
				String propertyName = entry.getKey();
				//反射得到对应的Filed
				Field field = clazz.getDeclaredField(propertyName);
				field.setAccessible(true);
				Object value = field.get(object);
				
				params[index] = value;
				
				//一个列名对应一个?
				sqlSb.append(columnName);
				paramSb.append("?");
				//entrySet的size就是列名的个数
				if(index == entrySet.size()-1){
					break;
				}
				
				sqlSb.append(",");
				paramSb.append(",");
				
				index ++;
			}
			
			
			sqlSb.append(") values(");
			
			//拼接问号
			sqlSb.append(paramSb.toString());
			
			sqlSb.append(")");
			
			//System.out.println(sqlSb.toString());
			
			
			queryRunner.update(sqlSb.toString(),params);
			
	}*/
		

	
	

}
